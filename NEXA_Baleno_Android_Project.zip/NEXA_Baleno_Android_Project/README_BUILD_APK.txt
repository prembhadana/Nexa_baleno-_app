NEXA BALENO QUOTATION - ANDROID STUDIO PROJECT

This is an Android WebView wrapper project for the Baleno quotation app.
It includes the supplied Baleno image and NEXA Safety Shield image embedded in the offline HTML app.

BUILD APK (requires Android Studio + Android SDK):
1. Extract this ZIP on a computer.
2. Open the NEXA_Baleno_Android_Project folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio creates app-debug.apk under app/build/outputs/apk/debug/.

This environment does not have Android SDK / Gradle installed, so a compiled and signed APK cannot honestly be supplied from this session. This ZIP is the ready-to-build Android Studio project, not an APK.

The app works offline in the WebView. Internet-based automatic vehicle image lookup is not included; the provided Baleno brochure image is bundled.
