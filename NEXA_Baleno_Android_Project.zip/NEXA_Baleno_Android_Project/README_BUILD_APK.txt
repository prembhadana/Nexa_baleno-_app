NEXA CARS - Android APK build project

App display name: Nexa Cars
Launcher icon: uploaded NEXA logo
Quotation branding: NEXA Autonation, Palwal

Build with GitHub Actions workflow already in your repository. Upload this ZIP to the repository root, replacing the previous NEXA_Baleno_Android_Project.zip, then commit. The existing android-apk.yml workflow should run and create the NEXA-Baleno-debug-APK artifact.

The project targets Java/Kotlin JVM 17 to avoid the earlier JVM-target mismatch. This is a debug/testing APK, not a Play Store release build.
