package com.nexa.quotation

import android.app.Activity
import android.os.Bundle
import android.os.Environment
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.view.ViewGroup
import android.content.ContentValues
import android.provider.MediaStore
import android.net.Uri
import android.widget.Toast
import android.util.Base64
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.addJavascriptInterface(QuotationDownloadBridge(), "NexaAndroid")
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class QuotationDownloadBridge {
        @JavascriptInterface
        fun saveQuotationImage(dataUrl: String, requestedName: String): String {
            return try {
                val base64Data = dataUrl.substringAfter(",", "")
                if (base64Data.isBlank()) return "Image data was empty."
                val bytes = Base64.decode(base64Data, Base64.DEFAULT)
                val safeName = requestedName
                    .replace(Regex("[^A-Za-z0-9._-]"), "_")
                    .let { if (it.endsWith(".png")) it else "$it.png" }

                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, safeName)
                        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                        put(
                            MediaStore.Images.Media.RELATIVE_PATH,
                            Environment.DIRECTORY_PICTURES + "/NEXA Quotations"
                        )
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                    val uri: Uri = contentResolver.insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        values
                    ) ?: return "Could not create the image file."
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                        ?: return "Could not write the image file."
                    val done = ContentValues().apply {
                        put(MediaStore.Images.Media.IS_PENDING, 0)
                    }
                    contentResolver.update(uri, done, null, null)
                    runOnUiThread {
                        Toast.makeText(
                            this@MainActivity,
                            "Quotation saved in Gallery > Pictures > NEXA Quotations",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    "Saved to Gallery > Pictures > NEXA Quotations"
                } else {
                    val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
                        ?: return "Storage folder is unavailable."
                    val folder = File(dir, "NEXA Quotations")
                    folder.mkdirs()
                    FileOutputStream(File(folder, safeName)).use { it.write(bytes) }
                    runOnUiThread {
                        Toast.makeText(
                            this@MainActivity,
                            "Quotation saved in app Pictures folder",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    "Quotation image saved."
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "Download failed: ${e.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
                "Download failed: ${e.message ?: "Unknown error"}"
            }
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
